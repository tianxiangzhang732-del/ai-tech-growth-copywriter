# 中文 AI 科技口播写稿助手

给 Codex 一份选题、产品材料或现成草稿，即可起草中文科技口播、标题和封面文案，也可以只诊断开头、共鸣点或转发理由。完整写稿会检查开头的承诺能否在正文中兑现，并区分实测、公开事实和待验证的判断。[查看技能入口](SKILL.md)

## 安装到 Codex

1. 下载并解压 ZIP，找到直接包含 `SKILL.md`、`agents` 和 `references` 的 `ai-tech-growth-copywriter` 文件夹。
2. 选择下表中的一个位置，把整个文件夹复制过去。缺少 `.agents` 或 `skills` 文件夹时可以新建。
3. 在 Codex 中打开相应项目并新建对话，输入 `$ai-tech-growth-copywriter` 选用技能；如果列表还未更新，重新启动 Codex。安装正确时，`SKILL.md` 位于技能文件夹的第一层。

| 使用范围 | 将技能放在这里 |
|---|---|
| 仅一个项目 | 项目根目录下的 `.agents/skills/ai-tech-growth-copywriter/` |
| Windows 当前用户的所有项目 | `%USERPROFILE%\.agents\skills\ai-tech-growth-copywriter\` |
| macOS 或 Linux 当前用户的所有项目 | `~/.agents/skills/ai-tech-growth-copywriter/` |

## 试一次

> 用 $ai-tech-growth-copywriter 帮我改这篇科技口播的前五秒。读者是第一次选择 AI 工具的产品经理。请从正文找出能兑现的承诺，给两个开头，并说明各自需要展示哪份证据。草稿如下……

写完整稿时，可以再说明平台、时长、固定问候和可展示的材料。只给选题也可以，助手会指出还缺哪些证据。[五项方法的用法与示例](references/editorial-workflow.md)

## 署名与使用范围

本仓库发布者编写和整理了科技口播写稿流程、风格选择、脚本模板与样本校准指引，并将五项外部方法接入口播流程。原创部分公开供下载、学习和个人非商业使用，著作权归相应权利人所有。公开分享未授予原创部分的商业使用许可。

`ra-hook` 作者为雪踏乌云（Pluviobyte / @Pluvio9yte）。`dbs-content`、`dbs-hook`、`dbs-resonate`、`dbs-spread` 原作为 @dontbesilent，本包采用雪踏乌云整合的版本。五项引入材料及其改编部分适用 CC BY-NC 4.0；转发或改编这些材料时，请保留署名、许可链接及更改说明，商业使用须取得相应权利人授权。[来源、版本与改编说明](references/upstream/NOTICE.md) · [第三方许可](references/upstream/LICENSE)
