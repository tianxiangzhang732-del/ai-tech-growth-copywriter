# 原作者与许可

本目录使用 [Pluviobyte/rnskill 固定版本](https://github.com/Pluviobyte/rnskill/tree/83d1783b892bbaa29a137895ff8338264b6872fa)。该版本将本次五个模块列为署名－非商业性使用 4.0 国际许可，适用于五项引入的材料及其改编部分。商单、付费产品或其他商业使用需要相应权利人的授权。原创部分的使用范围见[本包使用说明](../../README.md)。[仓库许可原件](LICENSE) · [CC BY-NC 4.0 许可全文](https://creativecommons.org/licenses/by-nc/4.0/legalcode)

| 模块 | 署名与版本 |
|---|---|
| ra-hook | 雪踏乌云（Pluviobyte / @Pluvio9yte）。[固定版本](https://github.com/Pluviobyte/rnskill/tree/83d1783b892bbaa29a137895ff8338264b6872fa/skills/ra-hook) |
| dbs-content、dbs-hook、dbs-resonate、dbs-spread | 原作 @dontbesilent，使用雪踏乌云整合的版本。[原作者项目](https://github.com/dontbesilent2025/dbskill) · [合集署名说明](https://github.com/Pluviobyte/rnskill/blob/83d1783b892bbaa29a137895ff8338264b6872fa/README.md) |

本次改编将五个入口接入中文科技口播工作流，增加类型选择、证据使用和输出范围指引。五份模块说明在此目录改名为各自的 `method.md`，正文未经改写；内容诊断的知识库保留原有文件和目录。合集中的独立技能界面配置由本技能统一入口代替。
