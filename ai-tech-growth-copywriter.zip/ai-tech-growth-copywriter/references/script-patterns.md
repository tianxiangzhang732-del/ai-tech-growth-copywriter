# Script Patterns

Use these patterns to create original Chinese AI tech scripts quickly.

## Hook Bank

- Result-first: "我用 AI 做完了一个真实的 [task]，最意外的是 [specific result/failure]。"
- Contradiction: "大家都在聊 [hot topic]，但真正改变普通人的不是 [obvious thing]，而是 [hidden variable]。"
- Audience mirror: "如果你已经收藏了几十个 AI 工具，但工作里还是用不上，问题可能不是你懒。"
- Decision fork: "[Tool/model/workflow] 到底该不该用？我只看三个标准。"
- Number proof: "我用 [time/cost/sample size] 测了 [tool/workflow]，结论和宣传不太一样。"
- Myth correction: "别再把 [concept] 理解成 [wrong analogy] 了，它更像 [better analogy]。"

## 35-Second Structure

Use for timely topics and simple takeaways.

1. 0-3s: result, contradiction, or decision question.
2. 3-8s: who this matters to.
3. 8-20s: two causal points or workflow steps.
4. 20-28s: proof, caveat, or failure.
5. 28-35s: practical conclusion and comment question.

## 70-Second Structure

Use for tutorials, comparisons, and explainers.

1. 0-4s: visible payoff or surprising thesis.
2. 4-10s: contract with viewer.
3. 10-25s: context and setup.
4. 25-50s: three beats: test, evidence, complication.
5. 50-62s: judgment: who should use it, who should not.
6. 62-70s: CTA tied to viewer use case.

## Title Formulas

- "我用 [AI tool] 做了 [real task]，最值钱的是这一步"
- "[AI hot topic] 真正影响普通人的地方，不是你想的那个"
- "别急着学 [tool/model]，先看懂这 3 个判断标准"
- "[role/audience] 用 AI 的正确顺序：先别买课"
- "我替你测了 [workflow]：省时间，但有一个坑"

## Cover Copy Rules

- Keep cover copy under 12 Chinese characters when possible.
- Put the strongest noun and outcome first.
- Use contrast: "省时但翻车", "不是替代，是放大", "3类人别学".
- Avoid vague hype: "震惊", "必看", "颠覆", "全网最强".

## CTA Patterns

- Comment use case: "你想让我拿 AI 测哪个真实任务？"
- Decision poll: "你现在更缺工具、方法，还是判断力？"
- Objection invite: "你不同意哪一点？我拿样本再测一轮。"
- Series conversion: "下条我会把这个流程拆成可复制模板。"

## Fact-Check Table Template

| Claim | Evidence Needed | Certainty | Safer Wording |
|---|---|---|---|
| [specific claim] | [source/demo/benchmark] | high/medium/low | [qualified version] |

## Revision Checklist

- Delete lecture openings like "今天给大家分享".
- Replace vague "很强" with a visible result or criterion.
- Add one caveat to every strong recommendation.
- Make every technical word earn its place.
- End with a question that produces useful comments, not generic engagement.
