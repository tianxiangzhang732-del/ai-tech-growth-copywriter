# Calibration Guide

Use this file when updating the skill from creator samples, account analytics, or platform rankings.

## Evidence Standard

Public "全网粉丝量 Top 30" rankings are usually platform-specific, date-specific, category-specific, and sometimes paywalled. Before claiming a ranking, record:

- platform or data vendor;
- ranking date;
- category definition;
- whether the metric is followers, engagement, growth, or commercial influence;
- account URLs or IDs;
- visible follower counts and capture date.

If any item is missing, call it a directional sample, not a definitive ranking.

## Sampling Sheet

| Account | Platform | URL/ID | Date | Followers | Topic | Duration | First sentence | Hook type | Structure | Proof asset | CTA | Notes |
|---|---|---|---|---:|---|---:|---|---|---|---|---|---|

Sample 8-12 recent posts per account where possible: high, median, and low performance. Avoid using only viral posts.

## Convert Samples into Transfer Rules

For every observed pattern, write:

- Observation: directly visible or countable behavior.
- Inference: why it may work.
- Confidence: low, medium, or high.
- Transfer rule: how the user can use the mechanism without copying the expression.

Example:

- Observation: Several tutorial posts show the final output before the tool setup.
- Inference: visible payoff lowers uncertainty and increases hold.
- Confidence: medium until sample size is confirmed.
- Transfer rule: show the user's authentic output or failed attempt in the first 3 seconds.

## 阅读公开样本

用同一平台、同一时间范围的原帖形成样本，记录观察日期和可回看的证据。把“首句展示了实际结果”这类可观察动作与“观众更愿意看下去”这类待验证解释分开。账号名只用于用户要求的来源分析，成稿提炼可迁移的写作方法。

## Update Rule

Only update shared archetypes when a pattern is stable across multiple samples and remains usable as an original mechanism. Store account-specific observations and metrics in the user's own private project.
