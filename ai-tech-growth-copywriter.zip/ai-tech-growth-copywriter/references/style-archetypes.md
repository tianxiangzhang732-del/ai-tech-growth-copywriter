# AI 科技博主涨粉文案风格类型库

Use these archetypes as transferable mechanisms. Do not present them as exact descriptions of any named creator unless calibrated from primary samples.

## 1. 结果先行型

Best for tutorials, tool tests, prompt workflows, automation demos.

- Opening: 先给结果或对比图，再解释怎么做到。
- Structure: 结果 -> 适用人群 -> 三步过程 -> 失败点 -> 可复用模板 -> 评论区问题。
- Growth mechanism: 降低观看不确定性，提升收藏和转发。
- Signature move: "我用它做了一个真实任务，结论是..."
- Avoid: 只秀炫技、不说成本、失败率、适用边界。

Use when the content has a visible artifact: PPT, Excel,海报,视频,代码,自动化流程,报告,客服机器人,知识库。

## 2. 反常识解释型

Best for AI news, model launches, industry competition, policy or labor-impact topics.

- Opening: 抛出一个和大众直觉相反但可证明的判断。
- Structure: 流行说法 -> 关键矛盾 -> 背后变量 -> 对普通人的影响 -> 行动建议。
- Growth mechanism: 强观点带来停留和评论，因果解释带来信任。
- Signature move: "这件事真正重要的不是 A，而是 B。"
- Avoid: 情绪化唱反调、证据不足地制造焦虑。

Use when the viewer has heard the news but does not know why it matters.

## 3. 人话翻译型

Best for explaining model concepts, AI agent, MCP,上下文窗口,蒸馏,多模态,推理模型,开源闭源。

- Opening: 用一个生活类比或工作场景翻译术语。
- Structure: 术语一句话 -> 错误理解 -> 正确类比 -> 真实例子 -> 你该怎么判断。
- Growth mechanism: 面向泛知识用户，容易获得关注和转发。
- Signature move: "你可以把它理解成..."
- Avoid: 类比喧宾夺主、概念解释过长、没有使用场景。

Use when a technical term is becoming hot but大众理解还很模糊。

## 4. 商业拆解型

Best for AI company case studies, pricing,融资,产品增长,出海,应用层机会。

- Opening: 用一个数字、商业结果或具体公司动作切入。
- Structure: 表层动作 -> 商业模型 -> 用户痛点 -> 增长杠杆 -> 对创业者/打工人的启发。
- Growth mechanism: 把科技内容转成机会判断，吸引高价值关注。
- Signature move: "这个产品厉害的地方不是技术，而是它卡住了一个分发/成本/场景问题。"
- Avoid: 只复述融资新闻、把所有案例都讲成财富故事。

Use when the viewer wants判断一个 AI 产品为什么能火、能不能赚钱、能不能学。

## 5. 亲历实验型

Best for first-hand tool tests and questions raised in viewer comments.

- Opening: 说清楚你亲自测试的任务、约束和结果。
- Structure: 问题 -> 设置 -> 过程 -> 意外 -> 结论 -> 下次测试。
- Growth mechanism: 观众能根据实测条件判断结论是否适用于自己，也能在评论区提出下次想看的测试。
- Signature move: "我替你踩了一遍，最容易翻车的是..."
- Avoid: 只给结论不展示过程、把一次测试说成普遍规律。

Use when you can show screen recording,时间成本,对比样本,失败案例。

## 6. 情绪共鸣型

Best for AI 焦虑、职业转型、普通人学习 AI、创作者瓶颈。

- Opening: 命名一个具体、真实、克制的焦虑或愿望。
- Structure: 真实情境 -> 错误解法 -> 更好的判断框架 -> 一个小行动。
- Growth mechanism: 让观众感觉被理解，再提供控制感。
- Signature move: "你不是学不会 AI，你是不知道该把它放进哪个工作流里。"
- Avoid: 贩卖恐慌、空泛鸡汤、用绝对化语言承诺逆袭。

Use when the topic本质是人的决策，不只是工具本身。

## 7. 清单决策型

Best for tool comparisons,学习路径,模型选择,工作流选择。

- Opening: 给出明确选择问题。
- Structure: 谁适合 -> 三个标准 -> 选项对比 -> 我的选择 -> 不适合谁。
- Growth mechanism: 保存率强，帮助用户做决策，利于关注。
- Signature move: "如果你是 X，选 A；如果你是 Y，选 B。"
- Avoid: 用过多选项拖慢节奏、没有个人判断。

Use when viewers face information过载 and need a practical filter.

## 按本期材料选择组合

- 工具实测有可展示的产出时，以结果先行型起稿。操作里的术语会挡住新手时，可以加入人话翻译型。
- 产品新闻有财报、公告或价格表时，商业拆解型能把变化说具体。有足够证据挑战常见说法时，再加入反常识解释型。
- 创作者做过同一任务的多次实验时，用亲历实验型交代试验条件。观众正面临多个选项时，可以用清单决策型做收束。
