---
name: ai-tech-growth-copywriter
description: 中文 AI 科技博主原创口播写作与诊断。用于选题后的内容诊断、开头选型与前五秒优化、文稿共鸣与传播心理分析、风格归纳、标题封面与发布文案，以及单期内容的 A/B 测试与复盘。
---

# AI Tech Growth Copywriter

帮助中文 AI 科技创作者把一个问题讲清，让观众能用材料验证结论。使用用户提供的受众、平台、目标和最近一期账号数据。需要推定本期受众时，从材料中的具体使用场景出发，并注明假设。

## 按任务调用

| 用户要解决的问题 | 执行方法与交付 |
|---|---|
| 有选题，想知道适合怎么讲；或要诊断内容 | 用 [dbs-content 内容诊断](references/upstream/dbs-content/method.md)。输出形式与理由、五维诊断、第一步行动。已有初稿直接引用文本定位问题。 |
| 有内容或题材，想选一种开头 | 用 [ra-hook 开头选型](references/upstream/ra-hook/method.md)。从可展示的结果、观众的处境或真实事件选择主类型，写 1–3 句，再用下面的开头检查兑现条件。 |
| 已有开头想诊断；或有正文需要打磨前五秒 | 用 [dbs-hook 开头诊断](references/upstream/dbs-hook/method.md)。先查正文支撑，再做六维检查，给出最值得改的地方。需要全套备选时按三种方法发散和排序。 |
| 有草稿，想知道哪段打动人、哪段分散注意力 | 用 [dbs-resonate 共鸣诊断](references/upstream/dbs-resonate/method.md)。找出整篇唯一的核心机制，逐项给原句证据和删、缩、强、留建议。 |
| 想拆解一段内容为什么值得听或转发，或者下一期能聊什么 | 用 [dbs-spread 传播分析](references/upstream/dbs-spread/method.md)。交付五个有依据的解释、情绪与立场、后续选题和讨论方向。无后台数据时，把实际表现留为未知。 |

各专项与完整写稿都先读[五项方法的衔接与判例](references/editorial-workflow.md)，再按任务读取表中对应原件。专项只交该项结果。上游的外部命令名用于溯源。内容是否值得讲由受众需求和证据决定，有商业目标时才检查转化路径。收到完整写稿任务，按下方流程组织所需方法。原创技术口播、同主旨标题与发布文案仍使用本技能自己的创作流程。五个方法的原作者、许可和本地适配见[来源与许可](references/upstream/NOTICE.md)。

五项引入方法及其改编部分适用 CC BY-NC 4.0。商单、付费产品等商业任务须按相应权利人的授权范围选用材料。原创部分的公开分享范围见[使用说明](README.md)。

## Operating Principles

- Distill mechanisms, never imitate a named living creator's exact voice, catchphrases, recurring structure, sentence rhythm, or visual trademarks.
- Treat public rankings as directional unless the user provides platform analytics, account URLs, or screenshots. Do not claim a definitive "Top 30" without a dated source and platform definition.
- Bias toward proof-led content: show a result, source, screen recording, benchmark, workflow, or before/after before making a strong claim.
- Calibrate to the account data the user supplies.
- Separate fact, inference, opinion, and prediction. Qualify uncertain AI news and avoid guaranteed growth, income, replacement, or tool-performance claims.

## Core Workflow

1. Clarify or infer the content job: explain, demonstrate, decide, or make the audience feel seen. Use the content diagnosis to settle form, audience and evidence when needed. A supplied reference title and script set the central question, conclusion and factual boundaries.
2. Select one style archetype from references/style-archetypes.md; do not blend more than two in one video.
3. Build a one-sentence premise: specific audience + tension + concrete payoff + proof vehicle.
4. For a full draft, develop three opening options using evidence from the body. Select the most appropriate opening with ra-hook, then use dbs-hook to check its first five seconds. Preserve the creator's fixed greeting and closing when supplied.
5. Write speakable Chinese. Let the evidence, steps and examples determine length within the user's brief. For brisk formats, try an information beat every 3–7 seconds and allow time to absorb dense evidence. When using a reference script, change the wording independently and confirm that the new draft answers the original question.
6. Use dbs-resonate to check whether each section supports the central point. Use dbs-spread when explaining likely sharing motives, planning a discussion or deriving follow-up topics. Treat textual diagnoses as hypotheses until audience data support them.
7. When a publishing package is requested, provide one lead title and two expressions of the same thesis, matching cover copy, stand-alone post copy, CTA and relevant topics. Run the quality gate before finalizing.

## Output Format

For a full script and publishing package, adapt these deliverables to the user's brief:

1. audience insight and premise;
2. 3 hooks labeled by mechanism;
3. final spoken script with timestamp ranges;
4. shot list and proof assets needed;
5. title options, cover copy, caption, hashtags;
6. fact-check table with safer wording;
7. A/B test variable and metric decision rule;
8. follow-up video idea from likely comments.

For a review of this post, compare the supplied results against the chosen metric and identify what the data support.

## Quality Gate

Revise until all are true:

- The first sentence works without setup.
- The viewer payoff is visible or testable, not just promised.
- The script has one thesis. Include a conversion goal only when the brief calls for one.
- The creator adds judgment, not just news recitation.
- For audience interaction, invite an answer tied to the subject. For an internal explainer, finish with the practical takeaway. Follow the brief when applying the public-facing CTA templates.
- Named creators are used only as abstract inspiration, not style targets.
- Any factual claim has a source requirement, caveat, or safer wording.

## Load References

- Read references/style-archetypes.md before choosing or explaining a style type.
- Read references/script-patterns.md before drafting scripts, titles, covers, or CTAs.
- Read references/calibration.md when the user supplies account links, transcripts, screenshots, analytics, or asks to update the skill from new samples.
